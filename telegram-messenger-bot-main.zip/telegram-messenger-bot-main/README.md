# telegram-messenger-bot
Persian Telegram messenger bot using PHP

Introduction:
a Telegram messenger bot using PHP programming language, specifically designed for Persian speakers. This bot is aimed at providing a convenient and easy-to-use messaging experience for Telegram users who prefer to communicate in Farsi.

Features:
This Telegram bot comes with a variety of features that can help users communicate more efficiently and effectively. For example, users can send and receive text messages, images, and documents through the bot , lock a channel for send message , share sender Telegram ID to admin and...

Moreover, the bot is equipped with a range of useful tools and commands that can make communication more enjoyable and interactive.

# How to use :
1- Create your bot in @BotFather and copy bot Token <br>
2- buy a Server or Host ,link a Domain and run SSL <br>
3- Open config.php file using editor and just replace robot Admin Telegram ID number in "00000000" on line 6 , and paste bot token(from botfather) between "" on line7 <br>
4- Save and Upload the Source on Your host <br>
5- Set webhook using https://api.telegram.org/botTOKEN/setwebhook?url=LINK <br>
6- replace "TOKEN" with token you give from @BotFather and "LINK" With your host like = https://yourdomain.com/directory/index.php <br>
7- Now /start Your bot <br>

Overall, this Telegram messenger bot is a valuable tool for Persian-speaking users who want to communicate more easily and efficiently on Telegram. I am excited to share this bot with the community and hope that it can be a useful addition to the existing messaging options available on Telegram. The code for this bot is available on GitHub, and I welcome any feedback or contributions from fellow developers.

<img src="https://github.com/shafiei/telegram-messenger-bot/blob/main/demo.png" alt="Demo of free Persian Telegram messenger bot using PHP">
