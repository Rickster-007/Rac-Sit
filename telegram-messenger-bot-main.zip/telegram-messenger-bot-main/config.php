<?php

// Robot source by https://shafiei.dev
// just replace robot Admin Telegram ID number in "00000000" on line 6 , and paste bot token(from botfather) between "" on line7

$Dev = 00000000; //ایدی ادمین
$Token = ""; //توکن ربات

?>
