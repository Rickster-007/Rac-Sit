# Fluid-simulation
A simple program to make a fluid simulation

![image](https://github.com/Coder-5657/Fluid-simulation/assets/157788773/23b0ac75-01c6-44ff-b0e8-811668d9639d)

![image](https://github.com/Coder-5657/Fluid-simulation/assets/157788773/c5fc1a8d-0f16-470e-8169-ed6f9487f280)

![image](https://github.com/Coder-5657/Fluid-simulation/assets/157788773/e457fcff-e79a-4a64-ba7c-1ca51dffb79c)

