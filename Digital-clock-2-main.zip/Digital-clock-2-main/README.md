# Digital-clock-2
A simple program to make a digital clock
Css-processor=SCSS

![image](https://github.com/Coder-5657/Digital-clock-2/assets/157788773/59640b61-6da3-4039-85f7-d857bde17f47)

