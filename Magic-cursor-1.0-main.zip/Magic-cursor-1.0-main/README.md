# Magic-cursor-1.0
A simple program to make a magic cursor

![image](https://github.com/Coder-5657/Magic-cursor-1.0/assets/157788773/323daa21-a106-44a6-be15-919cea390262)

![image](https://github.com/Coder-5657/Magic-cursor-1.0/assets/157788773/fcd79903-41ee-4313-96a3-641f02c8870f)

![image](https://github.com/Coder-5657/Magic-cursor-1.0/assets/157788773/e6f44cae-71cb-4399-81ec-48b003aa349e)

