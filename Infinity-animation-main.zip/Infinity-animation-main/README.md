# Infinity-animation
A simple program to make an animation

![image](https://github.com/Coder-5657/Infinity-animation/assets/157788773/56987edf-cc43-438f-a03b-534033fea56e)

