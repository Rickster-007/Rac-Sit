# Shape-animation
A simple program to make an animation

![image](https://github.com/Coder-5657/Shape-animation/assets/157788773/24d4db53-9d07-43b7-92ef-852e0d6ee923)
![image](https://github.com/Coder-5657/Shape-animation/assets/157788773/ee0f1d08-6ccf-4741-80ee-c824fa596c99)


