# AI-image-generator
AI IMAGE GENERATOR USING OPENAI API-KEY

![image](https://github.com/Coder-5657/AI-image-generator/assets/157788773/2c958b3b-796d-462c-97d2-2efdac20b884)

![image](https://github.com/Coder-5657/AI-image-generator/assets/157788773/197df3ca-1ceb-40e6-b5a5-a0b938f1e279)


