# Button Animation 🤩

https://github.com/anaslaghrissi/Button-Animation-5/assets/108026572/bf07ea80-0c42-4270-bdaa-8a01fde03a1b
