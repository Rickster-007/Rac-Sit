# Tic-tac-toe
A simple program to make a game

![image](https://github.com/Coder-5657/Tic-tac-toe/assets/157788773/c1d8ab6c-12bc-4ab0-84e7-aac5e9e6399f)

![image](https://github.com/Coder-5657/Tic-tac-toe/assets/157788773/32fceaba-45cf-4c53-9bbd-c977c2b925bb)



