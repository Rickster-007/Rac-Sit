(function() {
  new MagicCursor().watch();
})();
