MagicCursor.js
==============

A library providing cool cursor effects on a browser.

See <http://s-shin.github.io/MagicCursor.js/>.

License
-------

(C) 2014 Shintaro Seki

Licensed under the MIT License.

