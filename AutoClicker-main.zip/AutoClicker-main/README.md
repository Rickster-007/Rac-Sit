# AutoClicker
This is the best autoclicker that works without giving the location just point the cursor and see the magic guys.
