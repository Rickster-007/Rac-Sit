# Digital-clock-1
A simple program to make a digital clock
