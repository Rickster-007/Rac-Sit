# Glowing-icons
A simple program to make an icon animation
![image](https://github.com/Coder-5657/Glowing-icons/assets/157788773/a68d5f79-c55b-4e79-aedc-7f9710777b6e)
