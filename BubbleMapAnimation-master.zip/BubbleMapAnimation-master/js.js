jQuery(document).ready(function () {
    jQuery('.bubble-block').on('click', '.bubble-ico', function () {
        jQuery('#card').fadeToggle();
    })
})