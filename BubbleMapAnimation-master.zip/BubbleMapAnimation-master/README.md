# BubbleMapAnimation
Point's Animation for Custom BubbleMap
<br>
<a href="https://codepen.io/leonardopro/pen/moLbEQ" target="_blank">See the demo on codepen</a>
<br><br>
<div style="text-align: center;">
<img src="./screen_project.png" style="width: 720px; height:450px;">
</div>
