# Earth-evolution-animation
A simple program to make an animation
