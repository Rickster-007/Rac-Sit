# ip-whois
Use the IP WHOIS lookup tool to find the assigned owner, location, and abuse-reporting details of an IP address.
<img src="https://raw.githubusercontent.com/shafiei/ip-whois/main/banner.svg?raw=true" alt="">
