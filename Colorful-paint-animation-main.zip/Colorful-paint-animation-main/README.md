# Colorful-paint-animation
A simple program to make an animation

![image](https://github.com/Coder-5657/Colorful-paint-animation/assets/157788773/f49719f4-103a-4f6e-b502-e5e0fd107250)

