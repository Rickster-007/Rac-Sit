# Magic-cursor-3.0
A simple program to make a magic cursor

![image](https://github.com/Coder-5657/Magic-cursor-3.0/assets/157788773/42001e9a-032b-488f-9481-56098d3dc93a)

![image](https://github.com/Coder-5657/Magic-cursor-3.0/assets/157788773/070fe241-e4ac-4eb4-b58e-1917400862f3)
