# Box Animation 🤩

https://github.com/anaslaghrissi/Box-Animation/assets/108026572/4c305287-77d8-490e-8078-6808a127c6a4

