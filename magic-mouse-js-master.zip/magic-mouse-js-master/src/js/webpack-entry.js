export const magicMouse = (e) => {
 return 'hello world ' + e
}

export default magicMouse;
