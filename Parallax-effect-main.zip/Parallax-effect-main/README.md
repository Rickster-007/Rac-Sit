# Parallax-effect
A simple program to make an animation

![image](https://github.com/Coder-5657/Parallax-effect/assets/157788773/2c7ea250-ef08-4046-9c06-3871996d505d)

![image](https://github.com/Coder-5657/Parallax-effect/assets/157788773/47e8819f-73b1-48e8-86c1-84f878fd875b)

![image](https://github.com/Coder-5657/Parallax-effect/assets/157788773/f366949e-0b91-438f-afa7-239107caad9c)
