# Loading-text-effect
A simple program to make a text effect
