# MagicLine
A vertical line that hides one image and shows another image when you move the mouse cursor.

[**Смотреть Демо | See DEMO**](https://codepen.io/leonardopro/pen/LqdYVd)

![](./build/img/screen_project.png)
